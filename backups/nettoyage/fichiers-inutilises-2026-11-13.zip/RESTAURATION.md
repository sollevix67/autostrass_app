# Restauration des fichiers archivés

Cette archive conserve les neuf fichiers retirés du dépôt le 13 novembre 2026,
avec leurs chemins relatifs d'origine. MANIFEST.json liste leurs tailles et
empreintes SHA-256 et indique le commit de départ.

Pour restaurer les fichiers, extraire le ZIP dans un dossier temporaire, puis
copier les fichiers listés dans MANIFEST.json à la racine du dépôt en conservant
leurs sous-dossiers. Les deux documents MANIFEST.json et RESTAURATION.md servent
uniquement à décrire la sauvegarde. Vérifier les empreintes SHA-256 après copie.
